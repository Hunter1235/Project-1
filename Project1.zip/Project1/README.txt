Author  Hunter Stiles   3/3/2021


This program reads GDP data for the US and China.  It figures out the
average yearly growth for each country and use it to predict the growth.
until 2030.  It creates a graph showing the GDP for the US and China, that
includes the predicted years until 2030.   This was the first project which
was done a few weeks into the python course.


Files
GDP1.py -- the application

America.csv -- the GDP data for the US.

China.cvs -- the GDP data for China

graph_output.bmp -- the graph of GDP for the US and China that is created by
the program.

text_output.bmp -- the text output of the program.

